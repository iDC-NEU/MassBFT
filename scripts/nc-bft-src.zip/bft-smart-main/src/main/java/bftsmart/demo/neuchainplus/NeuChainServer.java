package bftsmart.demo.neuchainplus;

import bftsmart.proto.RPCResponse;
import bftsmart.reconfiguration.util.Configuration;
import bftsmart.tests.serverconnection.RPCClient;
import bftsmart.tom.MessageContext;
import bftsmart.tom.ServiceProxy;
import bftsmart.tom.ServiceReplica;
import bftsmart.tom.core.TOMLayer;
import bftsmart.tom.server.defaultservices.DefaultRecoverable;
import io.grpc.stub.StreamObserver;

public class NeuChainServer extends DefaultRecoverable {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Usage: java ... YCSBServer <group_id> <replica_id>");
            return;
        }
        Configuration.GlobalVariables.bftGroupId = Integer.parseInt(args[0]);
        Configuration.GlobalVariables.bftNodeId = Integer.parseInt(args[1]);
        int localId = Configuration.GlobalVariables.bftNodeId;
        boolean crash = false;
        NeuChainServer server = new NeuChainServer(localId);
        TOMLayer tom = server.replica.getTOMLayer();
        while (tom.isRetrievingState()) {
            tom.getDeliveryThread().waitUntilCanDeliver();
        }
        bftsmart.proto.RPCResponse responseNow = null;
        final RPCResponse[] responseNext = {null};
        final ResettableCountDownLatch finishLatch = new ResettableCountDownLatch(1);
        StreamObserver<bftsmart.proto.RPCResponse> responseObserver = new StreamObserver<bftsmart.proto.RPCResponse>() {
            @Override
            public void onNext(bftsmart.proto.RPCResponse response) {
                responseNext[0] = response;
            }

            @Override
            public void onError(Throwable t) {
                System.err.println("Request error: " + t.getMessage());
                finishLatch.countDown();
            }

            @Override
            public void onCompleted() {
                finishLatch.countDown();
            }
        };

        while (true) {
            // blocks until this replica learns to be the leader for the current epoch of the current consensus
            tom.waitForLeader();
            tom.waitForPaxosToFinish();
            if (responseNow == null) {  // init
                responseNow = server.client.sendRequestProposal(tom.getLastExec()+1);
                if (responseNow == null) {
                    break;  // network error
                }
            } else {    // normal case
                // wait until respNext is ready
                finishLatch.await();
                responseNow = responseNext[0];
                finishLatch.reset();
            }
            // get responseNext async
            server.client.sendRequestProposalAsync(tom.getLastExec()+2, responseObserver);

            if (!responseNow.getSuccess()) {
                if (!tom.isDoingWork()) {
                    return; // local server is exited
                }
                continue;   // retry
            }
            if(crash && tom.getLastExec() == 50 && localId == 0) {
                server.replica.stop();
                server.proxy.invokeOrdered(responseNow.getPayload().toByteArray());
                return;
            }
            server.proxy.invokeOrdered(responseNow.getPayload().toByteArray());
        }
    }

    private NeuChainServer(int id) {
        proxy = new ServiceProxy(id);
        replica = new ServiceReplica(id, this, this);
        client = replica.getTOMLayer().controller.getStaticConf().getRPCClient();
    }

    @Override
    public byte[][] appExecuteBatch(byte[][] commands, MessageContext[] msgCtx, boolean fromConsensus) {
        return new byte[commands.length][];
    }

    @Override
    public byte[] appExecuteUnordered(byte[] theCommand, MessageContext theContext) {
        return new byte[]{};
    }

    @Override
    public void installSnapshot(byte[] state) { }

    @Override
    public byte[] getSnapshot() {
        return new byte[]{};
    }

    private final ServiceReplica replica;
    private final ServiceProxy proxy;
    private final RPCClient client;
}