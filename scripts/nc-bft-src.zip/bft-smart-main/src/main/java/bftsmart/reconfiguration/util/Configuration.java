package bftsmart.reconfiguration.util;

import bftsmart.tests.serverconnection.RPCClient;
import bftsmart.tom.util.KeyLoader;
import bftsmart.tom.util.TOMUtil;
import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.ManagedChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetSocketAddress;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class Configuration {
	public static class GlobalVariables {
		public static int bftGroupId = -1;
		public static int bftNodeId = -1;
	}
	private final Logger logger;
	protected int processId;
	protected Map<String, String> configs;
	protected HostsConfig hosts;
	protected KeyLoader keyLoader;
	public static final String DEFAULT_SECRETKEY = "PBKDF2WithHmacSHA1";
	public static final String DEFAULT_SECRETKEY_PROVIDER = "SunJCE";
	public static final String DEFAULT_SIGNATURE = "ED25519";
	public static final String DEFAULT_SIGNATURE_PROVIDER = "SunEC";
	public static final String DEFAULT_HASH = "SHA-256";
	public static final String DEFAULT_HASH_PROVIDER = "SUN";
	protected String secretKeyAlgorithm;
	protected String secretKeyAlgorithmProvider;
	protected String signatureAlgorithm;
	protected String signatureAlgorithmProvider;
	protected String hashAlgorithm;
	protected String hashAlgorithmProvider;
	protected String configHome;
	protected boolean defaultKeys = false;
	protected RPCClient rpcClient;

	public Configuration(int procId, String configHomeParam, KeyLoader loader) {
		logger = LoggerFactory.getLogger(this.getClass());
		processId = procId;
		configHome = configHomeParam;
		keyLoader = loader;
	}

	public final RPCClient getRPCClient() {
		return rpcClient;
	}

	protected void init() {
		try {
			hosts = new HostsConfig(processId);
			// load RPCPort from config file
			String target = hosts.getHost(processId) + ":" + getRPCPort();
			logger.info("RPC address: " + target);
			ManagedChannel channel = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
			rpcClient = new RPCClient(channel, processId);

			loadConfig();

			String s = configs.remove("system.communication.secretKeyAlgorithm");
			if (s == null) {
				secretKeyAlgorithm = DEFAULT_SECRETKEY;
			} else {
				secretKeyAlgorithm = s;
			}

			s = configs.remove("system.communication.signatureAlgorithm");
			if (s == null) {
				signatureAlgorithm = DEFAULT_SIGNATURE;
			} else {
				signatureAlgorithm = s;
			}

			s = configs.remove("system.communication.hashAlgorithm");
			if (s == null) {
				hashAlgorithm = DEFAULT_HASH;
			} else {
				hashAlgorithm = s;
			}

			s = configs.remove("system.communication.secretKeyAlgorithmProvider");
			if (s == null) {
				secretKeyAlgorithmProvider = DEFAULT_SECRETKEY_PROVIDER;
			} else {
				secretKeyAlgorithmProvider = s;
			}

			s = configs.remove("system.communication.signatureAlgorithmProvider");
			if (s == null) {
				signatureAlgorithmProvider = DEFAULT_SIGNATURE_PROVIDER;
			} else {
				signatureAlgorithmProvider = s;
			}

			s = configs.remove("system.communication.hashAlgorithmProvider");
			if (s == null) {
				hashAlgorithmProvider = DEFAULT_HASH_PROVIDER;
			} else {
				hashAlgorithmProvider = s;
			}

			s = configs.remove("system.communication.defaultkeys");
			if (s == null) {
				defaultKeys = false;
			} else {
				defaultKeys = s.equalsIgnoreCase("true");
			}

			if (keyLoader == null) {
				keyLoader = new ECDSAKeyLoader(processId, configHome, useDefaultKeys(), getSignatureAlgorithm());
			}

			TOMUtil.init(
					getSecretKeyAlgorithm(),
					keyLoader.getSignatureAlgorithm(),
					getHashAlgorithm(),
					getSecretKeyAlgorithmProvider(),
					getSignatureAlgorithmProvider(),
					getHashAlgorithmProvider());

		} catch (Exception e) {
			LoggerFactory.getLogger(this.getClass()).error("Wrong system.config file format.");
		}
	}

	public String getConfigHome() {
		return configHome;
	}

	public boolean useDefaultKeys() {
		return defaultKeys;
	}

	public final String getSecretKeyAlgorithm() {
		return secretKeyAlgorithm;
	}

	public final String getSignatureAlgorithm() {
		return signatureAlgorithm;
	}

	public final String getHashAlgorithm() {
		return hashAlgorithm;
	}

	public final String getSecretKeyAlgorithmProvider() {
		return secretKeyAlgorithmProvider;
	}

	public final String getSignatureAlgorithmProvider() {
		return signatureAlgorithmProvider;
	}

	public final String getHashAlgorithmProvider() {
		return hashAlgorithmProvider;
	}

	public final String getProperty(String key) {
		Object o = configs.get(key);
		if (o != null) {
			return o.toString();
		}
		return null;
	}

	public final Map<String, String> getProperties() {
		return configs;
	}

	public final InetSocketAddress getRemoteAddress(int id) {
		return hosts.getRemoteAddress(id);
	}

	public final String getHost(int id) {
		return hosts.getHost(id);
	}

	public final int getPort(int id) {
		return hosts.getPort(id);
	}

	public final int getServerToServerPort(int id) {
		return hosts.getServerToServerPort(id);
	}

	public final int getRPCPort() {
		return hosts.getRPCPort();
	}

	public final int getProcessId() {
		return processId;
	}

	public final void addHostInfo(int id, String host, int port, int portRR) {
		this.hosts.add(id, host, port, portRR);
	}

	public PublicKey getPublicKey() {
		try {
			return keyLoader.loadPublicKey();
		} catch (Exception e) {
			logger.error("Could not load public key", e);
			return null;
		}
	}

	public PublicKey getPublicKey(int id) {
		try {
			return keyLoader.loadPublicKey(id);
		} catch (Exception e) {
			logger.error("Could not load public key", e);
			return null;
		}
	}

	public PrivateKey getPrivateKey() {
		try {
			return keyLoader.loadPrivateKey();
		} catch (Exception e) {
			logger.error("Could not load private key", e);
			return null;
		}
	}

	private void loadConfig() {
		configs = new HashMap<>();
		try {
			if (configHome == null || configHome.equals("")) {
				configHome = "config";
			}
			String sep = System.getProperty("file.separator");
			String path = configHome + sep + "system.config";
			FileReader fr = new FileReader(path);
			BufferedReader rd = new BufferedReader(fr);
			String line;
			while ((line = rd.readLine()) != null) {
				if (!line.startsWith("#")) {
					StringTokenizer str = new StringTokenizer(line, "=");
					if (str.countTokens() > 1) {
						configs.put(str.nextToken().trim(), str.nextToken().trim());
					}
				}
			}
			fr.close();
			rd.close();
		} catch (Exception e) {
			LoggerFactory.getLogger(this.getClass()).error("Could not load configuration", e);
		}
	}
}
