package bftsmart.reconfiguration.util;
import java.io.BufferedReader;
import java.io.FileReader;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import org.slf4j.LoggerFactory;

public class HostsConfig {
    private final HashMap<Integer, Config> servers = new HashMap<>();
    private int rpcPort = -1;

    public HostsConfig(int processId) {
        loadConfig(processId);
    }

    private void loadConfig(int processId) {
        try {
            if (processId != Configuration.GlobalVariables.bftNodeId) {
                Configuration.GlobalVariables.bftNodeId = processId;
            }
            String path = "config" + System.getProperty("file.separator");
            int groupId = Configuration.GlobalVariables.bftGroupId;
            if (groupId < 0) {
                path += "hosts.config"; // original version
            } else {
                path += "hosts_" + groupId + "_" + processId + ".config";
            }
            FileReader fr = new FileReader(path);
            BufferedReader rd = new BufferedReader(fr);
            String line;
            while ((line = rd.readLine()) != null) {
                if (!line.startsWith("#")) {
                    StringTokenizer str = new StringTokenizer(line, " ");
                    if (str.countTokens() == 5) {
                        int id = Integer.parseInt(str.nextToken());
                        String host = str.nextToken();
                        int port = Integer.parseInt(str.nextToken());
                        int portRR = Integer.parseInt(str.nextToken());
                        if (id == processId) {
                            rpcPort = Integer.parseInt(str.nextToken());
                        }
                        this.servers.put(id, new Config(id, host, port, portRR));
                    }
                }
            }
            fr.close();
            rd.close();
        } catch (Exception e) {
            LoggerFactory.getLogger(this.getClass()).error("Could not load configuration file", e);
        }
    }

    public void add(int id, String host, int port, int portRR) {
        if (this.servers.get(id) == null) {
            this.servers.put(id, new Config(id, host, port, portRR));
        }
    }

    public int getNum() {
        return servers.size();
    }

    public InetSocketAddress getRemoteAddress(int id) {
        Config c = this.servers.get(id);
        if (c != null) {
            return new InetSocketAddress(c.host, c.port);
        }
        return null;
    }

    public int getPort(int id) {
        Config c = this.servers.get(id);
        if (c != null) {
            return c.port;
        }
        return -1;
    }

    public int getServerToServerPort(int id) {
        Config c = this.servers.get(id);
        if (c != null) {
            return c.portRR;
        }
        return -1;
    }

    public int getRPCPort() {
        return rpcPort;
    }

    public int[] getHostsIds() {
        Set<Integer> s = this.servers.keySet();
        int[] ret = new int[s.size()];
        Iterator<Integer> it = s.iterator();
        int p = 0;
        while (it.hasNext()) {
            ret[p] = Integer.parseInt(it.next().toString());
            p++;
        }
        return ret;
    }

    public String getHost(int id) {
        Config c = this.servers.get(id);
        if (c != null) {
            return c.host;
        }
        return null;
    }

    public static class Config {
        public int id;
        public String host;
        public int port;
        public int portRR;

        public Config(int id, String host, int port, int portRR) {
            this.id = id;
            this.host = host;
            this.port = port;
            this.portRR = portRR;
        }
    }
}
