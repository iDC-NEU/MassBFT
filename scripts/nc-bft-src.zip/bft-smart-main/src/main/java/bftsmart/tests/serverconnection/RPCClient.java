package bftsmart.tests.serverconnection;

import bftsmart.consensus.messages.ConsensusMessage;
import bftsmart.proto.*;
import com.google.protobuf.ByteString;
import io.grpc.*;
import io.grpc.stub.StreamObserver;

import java.util.HashSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Sample client code that makes gRPC calls to the server.
 */
public class RPCClient {
    private static final Logger logger = Logger.getLogger(RPCClient.class.getName());

    private final RPCServiceGrpc.RPCServiceBlockingStub blockingStub;
    private final RPCServiceGrpc.RPCServiceStub asyncStub;
    private final int processId;

    /** Construct client for accessing RouteGuide server using the existing channel. */
    public RPCClient(Channel channel, int id) {
        blockingStub = RPCServiceGrpc.newBlockingStub(channel);
        asyncStub = RPCServiceGrpc.newStub(channel);
        processId = id;
    }

    public boolean sendVerifyProposal(int sequence, ByteString proposal) {
        RPCRequest request = RPCRequest.newBuilder()
                .setPayload(proposal)
                .setLocalId(processId)
                .setSequence(sequence)
                .build();

        try {
            bftsmart.proto.RPCResponse response = blockingStub.verifyProposal(request);
            return response.getSuccess();
        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed");
            e.printStackTrace();
        }
        return false;
    }

    public void sendLeaderStart(int sequence) {
        RPCRequest request = RPCRequest.newBuilder()
                .setLocalId(processId)
                .setSequence(sequence)  // the next consensus round
                .setPayload(ByteString.copyFromUtf8("LeaderStart"))
                .build();

        try {
            bftsmart.proto.RPCResponse response = blockingStub.leaderStart(request);
        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed");
            e.printStackTrace();
        }
    }

    public void sendLeaderChange(int newLeader, int sequence) {
        if (newLeader == processId) {
            return;
        }
        LeaderChangeRequest request = LeaderChangeRequest.newBuilder()
                .setLocalId(processId)
                .setSequence(sequence)  // the next consensus round
                .setNewLeaderId(newLeader)
                .build();

        try {
            bftsmart.proto.RPCResponse response = blockingStub.leaderChange(request);
        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed");
            e.printStackTrace();
        }
    }

    public bftsmart.proto.RPCResponse sendRequestProposal(int sequence) {
        RPCRequest request = RPCRequest.newBuilder()
                .setLocalId(processId)
                .setSequence(sequence)  // the next consensus round
                .setPayload(ByteString.copyFromUtf8("RequestProposal"))
                .build();
        try {
            return blockingStub.requestProposal(request);
        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed");
            e.printStackTrace();
        }
        return null;
    }

    public void sendRequestProposalAsync(int sequence, io.grpc.stub.StreamObserver<bftsmart.proto.RPCResponse> responseObserver) {
        RPCRequest request = RPCRequest.newBuilder()
                .setLocalId(processId)
                .setSequence(sequence)  // the next consensus round
                .setPayload(ByteString.copyFromUtf8("RequestProposal"))
                .build();
        try {
            asyncStub.requestProposal(request, responseObserver);
        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed");
            e.printStackTrace();
        }
    }

    public void sendDeliver(int leader, int sequence, HashSet<ConsensusMessage> proposal, byte[] proposeValue) {
        DeliverRequest.Builder builder = DeliverRequest.newBuilder()
                .setLocalId(processId)
                .setLeaderId(leader)
                .setSequence(sequence)
                .setProposeValue(ByteString.copyFrom(proposeValue));


        for (ConsensusMessage cm: proposal) {
            builder.addContents(ByteString.copyFrom(cm.serialize()));
            builder.addSignatures(ByteString.copyFrom((byte[]) cm.getProof2()));
        }

        try {
            bftsmart.proto.RPCResponse response = blockingStub.deliver(builder.build());
            if (!response.getSuccess()) {
                logger.warning("response.getSuccess() failed");
            }
        } catch (StatusRuntimeException e) {
            logger.warning("RPC failed");
            e.printStackTrace();
        }
    }

    public ByteString sendSignProposal(ByteString proposal) {
        RPCRequest request = RPCRequest.newBuilder()
                .setPayload(proposal)
                .setLocalId(processId)
                .build();
        try {
            bftsmart.proto.RPCResponse response = blockingStub.signProposal(request);
            if (response.getSuccess()) {
                return response.getPayload();
            }
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
        }
        logger.warning("RPC failed");
        return null;
    }

    public boolean sendVerifyProposalAsync(int sequence, ByteString proposal) {
        CountDownLatch finishLatch = new CountDownLatch(1);
        final boolean[] success = {false};
        StreamObserver<RPCResponse> responseObserver = new StreamObserver<RPCResponse>() {
            @Override
            public void onNext(RPCResponse summary) {
                logger.log(Level.INFO, summary.getPayload().toString());
                success[0] = summary.getSuccess();
            }

            @Override
            public void onError(Throwable t) {
                logger.log(Level.INFO, "RecordRoute Failed: {0}", Status.fromThrowable(t));
                finishLatch.countDown();
            }

            @Override
            public void onCompleted() {
                finishLatch.countDown();
            }
        };

        RPCRequest request = RPCRequest.newBuilder().setPayload(proposal)
                .setSequence(sequence)
                .setLocalId(processId)
                .build();
        asyncStub.verifyProposal(request, responseObserver);
        // Receiving happens asynchronously
        try {
            if (!finishLatch.await(1, TimeUnit.MINUTES)) {
                logger.warning("recordRoute can not finish within 1 minutes");
            }
        } catch (InterruptedException e) {
            logger.warning(e.toString());
        }
        return success[0];
    }

    /** Issues several requests and then exits. */
    public static void main(String[] args) throws InterruptedException {
        String target = "localhost:18888";
        ManagedChannel channel = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
        try {
            RPCClient client = new RPCClient(channel, 0);
            boolean ret = client.sendVerifyProposal(0, ByteString.copyFromUtf8("Proposal"));
            assert ret;
            ret = client.sendVerifyProposalAsync(0, ByteString.copyFromUtf8("AsyncProposal"));
            assert ret;
        } finally {
            channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
        }
    }

}