package bftsmart.tests.serverconnection;

import bftsmart.proto.RPCServiceGrpc;
import com.google.protobuf.ByteString;

public class RPCService extends RPCServiceGrpc.RPCServiceImplBase {
    @Override
    public void verifyProposal(bftsmart.proto.RPCRequest request,
                               io.grpc.stub.StreamObserver<bftsmart.proto.RPCResponse> responseObserver) {
        System.out.println("Handling hello endpoint: " + request.toString());
        String text = request.getPayload() + " World";
        bftsmart.proto.RPCResponse response = bftsmart.proto.RPCResponse.newBuilder()
                .setPayload(ByteString.copyFromUtf8(text))
                .setSuccess(true).build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }


}