/**
 Copyright (c) 2007-2013 Alysson Bessani, Eduardo Alchieri, Paulo Sousa, and the authors indicated in the @author tags

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */
package bftsmart.tom.util;

import bftsmart.proto.Proposal;
import bftsmart.tom.core.messages.TOMMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;

/**
 * Batch format: N_MESSAGES(int) + N_MESSAGES*[MSGSIZE(int),MSG(byte)] +
 *               TIMESTAMP(long) + N_NONCES(int) + NONCES(byte[])
 *
 */
public final class BatchReader {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private Proposal proposal = Proposal.getDefaultInstance();

    /** wrap buffer */
    public BatchReader(byte[] batch, boolean useSignatures) {
        try {
            proposal = Proposal.parseFrom(batch);
        } catch (InvalidProtocolBufferException e) {
            logger.error("wrong proposal!");
            System.exit(-1);
        }
        if (useSignatures) {
            logger.error("wrong config!");
            System.exit(-1);
        }
    }

    public TOMMessage[] deserialiseRequests() {
        //obtain the timestamps to be delivered to the application
        long timestamp = proposal.getTimestamp();
        int numberOfNonces = proposal.getNumberOfNonce();
        long seed = 0;
        Random rnd = null;
        if (numberOfNonces > 0) {
            seed = proposal.getSeed();
            rnd = new Random(seed);
        } else {
            numberOfNonces = 0; // make sure the value is correct
        }

        TOMMessage[] requests = new TOMMessage[1];
        byte[] message = proposal.getMessage().toByteArray();
        // obtain the nonces to be delivered to the application
        byte[] nonces = new byte[numberOfNonces];
        if (nonces.length > 0) {
            rnd.nextBytes(nonces);
        }

        try {
            TOMMessage tm = new TOMMessage();
            tm.rExternal(message);

            tm.serializedMessage = message;
            tm.serializedMessageSignature = null;
            tm.numOfNonces = numberOfNonces;
            tm.seed = seed;
            tm.timestamp = timestamp;
            requests[0] = tm;
        } catch (Exception e) {
            LoggerFactory.getLogger(this.getClass()).error("Failed to deserialize batch", e);
        }
        return requests;
    }
}
